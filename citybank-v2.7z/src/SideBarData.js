import React from "react";
import HomeIcon from '@material-ui/icons/Home';
import EmailIcon from '@material-ui/icons/Email';
import AssessmentIcon from '@material-ui/icons/Assessment';
import PeopleIcon from '@material-ui/icons/People';
import PhotoLibraryIcon from '@material-ui/icons/PhotoLibrary';
import DashboardIcon from '@material-ui/icons/Dashboard';


export const SideBarData = [
    {
        title : "Home",
        icon : <HomeIcon />,
        link : "/home"
    },
    {
        title : "Analytics",
        icon : <AssessmentIcon />,
        link : "/analytics"
    },
    {
        title : "Mailbox",
        icon : <EmailIcon />,
        link : "/email"
    },
    {
        title : "User Data",
        icon : <PeopleIcon />,
        link : "/getuser"
    },
    {
        title : "Fetch User",
        icon : <PeopleIcon />,
        link : "/get"
    },
    {
        title : "Add user",
        icon : <PeopleIcon />,
        link : "/add"
    }

];

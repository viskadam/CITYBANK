import { Button } from '@material-ui/core';
import React, { Component, useState } from 'react';
import axios from 'axios';

export default function PostdataJson() {

    const [email, setEmail] = React.useState("");
    const [password, setPassword] = React.useState("");
    const [res, setRes] = React.useState("");

    const textStyle = {
        width: "100%",
        padding: "12px 20px",
        margin: "8px 0",
        display: "inline-block",
        border: "1px solid #ccc",
        "border-radius": "4px",
        "box-sizing": "border-box"
    };

    let input = {
        "name": email,
        "job": password
    };

    const createuser = () => {

        axios.post('https://reqres.in/api/users', input)
            .then((response) => {
                setRes(response);
                console.log(response);
            })
            .catch(error => {
                console.error('There was an error!', error);
            });
    };

    return (
        <div className="postjsondata">
            <h2>Create User account</h2>
            <section>
                <label>
                    User name :
                    <input
                        name="username"
                        type="text"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                        style={textStyle} />
                </label>
            </section>
            <section>
                <label>
                    Company :
                    <input
                        name="job"
                        type="text"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        required
                        style={textStyle} />
                </label>
            </section>

            <button className="postjsondataSubmit" onClick={createuser} >Create</button>

            {res ? <>
                <h4>User Created succesfully</h4>
                <b>{JSON.stringify(res)}</b>
            </>
                : ""}
        </div>
    );
}

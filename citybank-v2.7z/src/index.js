import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Sidebar from './Sidebar';
import Header from './Header';

ReactDOM.render(
  <React.StrictMode>
    <div className="header-top"> 
        <Header title='CITY BANK' linkname='FB LINK' search={true} ></Header>
      </div>
      <div className="App rowC">
        <Sidebar />
        <App />
      </div>
    
  </React.StrictMode>,
  document.getElementById('root')
);


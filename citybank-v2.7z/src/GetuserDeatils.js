import React from 'react';
import axios from 'axios';
import './App.css';

function GetuserDeatils() {
    let [responseData, setResponseData] = React.useState("");
    let [userid, setUserid] = React.useState("");
  

    const fetchData = () => {
        const url = `https://reqres.in/api/users/${userid}`;
        console.log(url)
        axios({
            "method": "GET",
            "url": url
        })
            .then((response) => {
                setResponseData(response.data)
                console.log(response.data)
            })
            .catch((error) => {
                setResponseData('')
                console.log(error)
            })
    };

    React.useEffect(() => {
        ''
    }, [fetchData])

    return (

        <div className="container ">
           
                <h3 className="fontFamily">User data : </h3>
                {responseData ?
                <div className="card ">
                    <div className="card-body">
                        <h5 className="card-title">{responseData.data.first_name} {responseData.data.last_name}</h5>
                        <h6 className="card-subtitle mb-2 text-muted">
                            {responseData.data.email}
                        </h6>
                        <section>
                            <img src={responseData.data.avatar} alt="No Image Found" />
                        </section>
                    </div>
                </div>
                 : 
                    <b>NO USER DATA FOUND</b>
                 }   
                <section>
                    <input type="text" name="userid" value={userid} onChange={e => setUserid(e.target.value)}  />
                </section>
                 <button  className="postjsondataSubmit" onClick={fetchData}>Get User data</button>
        </div>
    );
}

export default GetuserDeatils;
import './App.css';
import { BrowserRouter, Route, Switch } from "react-router-dom";
import GetJSONData from './GetJSONData';
import PostdataJson from './PostdataJson';
import GetuserDeatils from './GetuserDeatils';
import axios from 'axios';

function App() {

  return (
    <>
     <BrowserRouter>
      <Switch>
        <Route exact path="/getuser" component={GetJSONData} />
        <Route path="/add" component={PostdataJson} />
        <Route path="/get" component={GetuserDeatils} />
        
      </Switch>
    </BrowserRouter>
      
    </>
  );
}

export default App;
